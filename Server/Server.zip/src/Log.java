/**
 * a class which can output log
 */
public class Log {
	
	/**
	 * constructor
	 * @return [constructor]
	 */
	public Log(){
		
	}
	
	/**
	 * write log
	 * @param s [log which will be wriiten]
	 */
	public void write(String s){
		System.out.println("----" + s + "----");
	}
}
