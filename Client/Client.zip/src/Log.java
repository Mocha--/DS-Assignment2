/**
 * log class which can print into console
 */
public class Log {
	
	public Log(){
		
	}
	
	public void write(String s){
		System.out.println(s);
	}
}
